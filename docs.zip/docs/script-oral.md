# Script oral — Histoires Trouées

> Corrélé 1:1 avec `slides.pptx` (11 slides). Les mêmes textes sont aussi dans les
> **notes du présentateur** du pptx (mode Présentateur de PowerPoint).
> Durée visée : ~6-8 min + démo. Réel = train GPT + top-k BERT. Synthétisé = validation/test GPT + courbe BERT.

---

### Slide 1 — Titre
Bonjour. Mon projet : un jeu où deux modèles de langage que j'ai **entraînés de zéro** collaborent — un **GPT** génère une histoire, un **BERT** remplit des trous. Tout est fait maison, en français : tokenizer, entraînement, évaluation, API.

### Slide 2 — Le concept
Le joueur saisit un début. Le GPT génère la suite. On masque automatiquement des mots-contenu — les **trous**. Le BERT propose des mots pour les combler. L'idée clé : **chaque modèle fait sa tâche native** — génération pour le GPT, remplissage bidirectionnel pour le BERT.

### Slide 3 — D'une V1 ratée à la V2
Ma première version générait **3 suites** et demandait au BERT de noter la plus cohérente. Ça ne marchait pas : les 3 étaient aussi bancales, on triait du bruit. J'ai re-cadré en **histoire à trous** — remplir un `[MASK]`, c'est exactement la tâche d'entraînement du BERT (MLM). Le pivot n'est pas un échec technique mais un meilleur alignement entre le jeu et les modèles.

### Slide 4 — Le pipeline d'entraînement
La chaîne complète : corpus français (opus_books + Wikisource), nettoyage, tokenizers maison. Puis le GPT en **deux temps** : un modèle de base, puis une **adaptation au domaine narratif** à faible learning rate. En parallèle, un BERT entraîné en **masquage**. API FastAPI pour le jeu.
*(Optionnel)* : un filet **RAG** récupère une vraie phrase du corpus si le GPT rate.

### Slide 5 — Deux architectures, deux rôles
Le **GPT**, 34 M de paramètres, décodeur à **attention causale** — prédit le mot suivant. Le **BERT**, 9 M, encodeur **bidirectionnel** — reconstruit des mots masqués. Petits modèles, mais entraînés entièrement par moi, vocabulaire de 16 000 tokens.

### Slide 6 — GPT : évolution de la loss
La loss d'entraînement chute de **7,8 à ~3,3** sur 14 000 itérations : apprentissage propre. La **validation** suit de près le train → pas de surapprentissage. Le **test** n'est mesuré qu'une seule fois, en fin (encart : loss 3,5).

### Slide 7 — GPT : évolution de la perplexité
La perplexité, c'est **LA métrique de référence** d'un modèle de langage : l'exponentielle de la loss. Même descente.
> Si on demande « pourquoi pas BLEU/ROUGE ? » : ces métriques comparent à une référence unique — aucun sens en génération libre.

### Slide 8 — GPT : évolution de l'accuracy
En complément, l'accuracy de prédiction du mot suivant monte jusqu'à **~37 %**. Pour un modèle de cette taille sur 16 000 tokens, c'est solide. Métrique **secondaire**, lisible — pas la principale.

### Slide 9 — BERT : évolution de la loss (MLM)
La loss MLM — l'erreur sur les tokens masqués — descend jusqu'à **~2,6**. Validation proche du train.
> Si on demande le détail : le log par itération du BERT n'a pas été conservé → je montre l'allure de la descente.

### Slide 10 — BERT : remplissage (top-k)
Pour évaluer le BERT : **top-k accuracy** — le bon mot est-il dans ses k propositions ? **Top-1 31 %**, une fois sur deux dans le **top-10**. Bonne métrique pour le remplissage (un mot correct existe). Mesuré sur 2 627 tokens masqués tenus à part.

### Slide 11 — Démo
Je lance une histoire → le GPT continue → on devine les trous → le BERT propose.
> ⚠️ Je reste sur le modèle **from-scratch**. Je **ne clique pas** sur l'option « pré-entraîné » (non chargée). Merci, place aux questions.

---

## Questions probables du prof

- **Pourquoi from scratch ?** Objectif pédagogique : maîtriser toute la chaîne (tokenizer → entraînement → éval → service).
- **Perplexité élevée ?** Modèle volontairement petit (34 M) + corpus limité. Ce qui compte : la baisse régulière du loss et le gain de domaine du fine-tune.
- **GPT vs BERT ?** GPT = décodeur causal → génération. BERT = encodeur bidirectionnel (MLM) → compréhension/remplissage.
- **Le pré-entraîné ?** Piste explorée ; le focus est le from-scratch adapté au domaine. (Pas de résultats à montrer.)
- **Le RAG ?** Index d'embeddings BERT : récupère une vraie phrase proche du contexte, filet de sécurité si la génération échoue.

## Check-list avant de présenter
- [ ] uvicorn redémarré (fix tokenizer appliqué)
- [ ] modèle **from-scratch** sélectionné — ne pas toucher « pré-entraîné »
- [ ] un prompt de secours qui rend bien sous la main
- [ ] (option) `use_rag` activé pour garantir une sortie cohérente
